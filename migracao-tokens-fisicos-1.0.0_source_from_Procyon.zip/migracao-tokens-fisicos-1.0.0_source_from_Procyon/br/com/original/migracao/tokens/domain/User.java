// 
// Decompiled by Procyon v0.5.36
// 

package br.com.original.migracao.tokens.domain;

import com.opencsv.bean.CsvBindByName;

public class User
{
    @CsvBindByName(column = "user")
    private String cpf;
    @CsvBindByName(column = "serial_number")
    private String serialNumber;
    private String wsClientName;
    private String wsClientSharedSecret;
    private String admLogin;
    private String admPassword;
    
    public User() {
    }
    
    public User(final String cpf, final String serialNumber, final String wsClientName, final String wsClientSharedSecret, final String admLogin, final String admPassword) {
        this.cpf = cpf;
        this.serialNumber = serialNumber;
        this.wsClientName = wsClientName;
        this.wsClientSharedSecret = wsClientSharedSecret;
        this.admLogin = admLogin;
        this.admPassword = admPassword;
    }
    
    public String getCpf() {
        return this.cpf;
    }
    
    public String getSerialNumber() {
        return this.serialNumber;
    }
    
    public String getWsClientName() {
        return this.wsClientName;
    }
    
    public String getWsClientSharedSecret() {
        return this.wsClientSharedSecret;
    }
    
    public String getAdmLogin() {
        return this.admLogin;
    }
    
    public String getAdmPassword() {
        return this.admPassword;
    }
}
