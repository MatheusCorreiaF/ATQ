// 
// Decompiled by Procyon v0.5.36
// 

package br.com.original.migracao.tokens.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Configuration;

@Configuration
@PropertySource({ "file:/opt/migracao-tokens-fisicos/global.properties" })
public class GlobalProperties
{
    @Value("${token.original.host}")
    private String host;
    @Value("${token.original.assign}")
    private String assignPath;
    
    public GlobalProperties() {
    }
    
    public GlobalProperties(final String host, final String assignPath) {
        this.host = host;
        this.assignPath = assignPath;
    }
    
    public String getHost() {
        return this.host;
    }
    
    public String getAssignPath() {
        return this.assignPath;
    }
}
