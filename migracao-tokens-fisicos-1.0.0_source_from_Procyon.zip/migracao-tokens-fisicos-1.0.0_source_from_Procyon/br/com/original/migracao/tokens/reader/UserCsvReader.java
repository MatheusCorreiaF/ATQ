// 
// Decompiled by Procyon v0.5.36
// 

package br.com.original.migracao.tokens.reader;

import java.io.Reader;
import com.opencsv.bean.CsvToBeanBuilder;
import br.com.original.migracao.tokens.domain.User;
import java.util.List;
import java.io.FileReader;

public class UserCsvReader
{
    private FileReader csv;
    
    public UserCsvReader(final FileReader csv) {
        this.csv = csv;
    }
    
    public List<User> getAllRows() {
        return (List<User>)new CsvToBeanBuilder((Reader)this.csv).withType((Class)User.class).build().parse();
    }
}
