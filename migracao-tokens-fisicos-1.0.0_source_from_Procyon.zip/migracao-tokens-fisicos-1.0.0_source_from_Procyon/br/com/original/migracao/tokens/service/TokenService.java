// 
// Decompiled by Procyon v0.5.36
// 

package br.com.original.migracao.tokens.service;

import java.net.URISyntaxException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.apache.http.client.utils.URIBuilder;
import br.com.original.migracao.tokens.model.TokenAssignResponse;
import org.springframework.http.ResponseEntity;
import br.com.original.migracao.tokens.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import br.com.original.migracao.tokens.utils.GlobalProperties;
import org.springframework.web.client.RestTemplate;
import org.springframework.stereotype.Service;

@Service
public class TokenService
{
    private RestTemplate restTemplate;
    private GlobalProperties gProperties;
    
    @Autowired
    public TokenService(final RestTemplate restTemplate, final GlobalProperties gProperties) {
        this.restTemplate = restTemplate;
        this.gProperties = gProperties;
    }
    
    public ResponseEntity<TokenAssignResponse> assignToken(final User user) throws URISyntaxException {
        final URIBuilder uriBuilder = new URIBuilder().setScheme("http").setHost(this.gProperties.getHost()).setPath(this.gProperties.getAssignPath()).setParameter("cpf", user.getCpf()).setParameter("serialNumber", user.getSerialNumber()).setParameter("wsClientName", user.getWsClientName()).setParameter("wsClientSharedSecret", user.getWsClientSharedSecret()).setParameter("admLogin", user.getAdmLogin()).setParameter("admPassword", user.getAdmPassword());
        return (ResponseEntity<TokenAssignResponse>)this.restTemplate.exchange(uriBuilder.build(), HttpMethod.GET, new HttpEntity((Object)user), (Class)TokenAssignResponse.class);
    }
}
