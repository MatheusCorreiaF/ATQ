// 
// Decompiled by Procyon v0.5.36
// 

package br.com.original.migracao.tokens.model;

public class TokenError
{
    private String errorCode;
    private String errorMessage;
    
    public TokenError() {
    }
    
    public TokenError(final String errorCode, final String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }
    
    public String getErrorCode() {
        return this.errorCode;
    }
    
    public void setErrorCode(final String errorCode) {
        this.errorCode = errorCode;
    }
    
    public String getErrorMessage() {
        return this.errorMessage;
    }
    
    public void setErrorMessage(final String errorMessage) {
        this.errorMessage = errorMessage;
    }
    
    @Override
    public String toString() {
        return "TokenError [errorCode=" + this.errorCode + ", errorMessage=" + this.errorMessage + "]";
    }
}
