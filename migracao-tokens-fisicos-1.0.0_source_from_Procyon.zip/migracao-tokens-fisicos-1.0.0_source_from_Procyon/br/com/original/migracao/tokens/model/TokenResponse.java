// 
// Decompiled by Procyon v0.5.36
// 

package br.com.original.migracao.tokens.model;

public class TokenResponse
{
    private boolean status;
    private TokenError error;
    
    public TokenResponse() {
    }
    
    public TokenResponse(final boolean status, final TokenError error) {
        this.status = status;
        this.error = error;
    }
    
    public TokenError getError() {
        return this.error;
    }
    
    public void setError(final TokenError error) {
        this.error = error;
    }
    
    public boolean isStatus() {
        return this.status;
    }
    
    public void setStatus(final boolean status) {
        this.status = status;
    }
}
