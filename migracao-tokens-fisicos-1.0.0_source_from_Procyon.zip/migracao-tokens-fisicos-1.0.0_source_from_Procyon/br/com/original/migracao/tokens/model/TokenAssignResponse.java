// 
// Decompiled by Procyon v0.5.36
// 

package br.com.original.migracao.tokens.model;

public class TokenAssignResponse extends TokenResponse
{
    private boolean isAssigned;
    
    public TokenAssignResponse() {
    }
    
    public TokenAssignResponse(final boolean status, final TokenError error) {
        super(status, error);
    }
    
    public boolean isAssigned() {
        return this.isAssigned;
    }
    
    public void setAssigned(final boolean isAssigned) {
        this.isAssigned = isAssigned;
    }
}
