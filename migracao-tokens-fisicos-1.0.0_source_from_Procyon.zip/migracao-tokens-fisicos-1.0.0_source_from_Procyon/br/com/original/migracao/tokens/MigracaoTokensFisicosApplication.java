// 
// Decompiled by Procyon v0.5.36
// 

package br.com.original.migracao.tokens;

import java.net.URL;
import java.io.FileNotFoundException;
import br.com.original.migracao.tokens.reader.UserCsvReader;
import java.io.FileReader;
import java.io.File;
import org.springframework.http.ResponseEntity;
import br.com.original.migracao.tokens.domain.User;
import java.util.List;
import java.net.URISyntaxException;
import br.com.original.migracao.tokens.model.TokenAssignResponse;
import org.springframework.boot.SpringApplication;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import br.com.original.migracao.tokens.service.TokenService;
import org.slf4j.Logger;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;

@SpringBootApplication
public class MigracaoTokensFisicosApplication implements CommandLineRunner
{
    private final Logger logger;
    @Autowired
    private TokenService service;
    
    public MigracaoTokensFisicosApplication() {
        this.logger = LoggerFactory.getLogger((Class)MigracaoTokensFisicosApplication.class);
    }
    
    public static void main(final String[] args) {
        SpringApplication.run((Class)MigracaoTokensFisicosApplication.class, args).close();
    }
    
    public void run(final String... args) throws Exception {
        final List<User> users = this.readUsersFromFile(args[0]);
        ResponseEntity<TokenAssignResponse> response;
        users.forEach(user -> {
            try {
                this.logger.info("Token {} a ser associado", (Object)user.getSerialNumber());
                response = this.service.assignToken(user);
                if (((TokenAssignResponse)response.getBody()).isStatus()) {
                    this.logger.info("Token {} associado com sucesso", (Object)user.getSerialNumber());
                }
                else {
                    this.logger.error(((TokenAssignResponse)response.getBody()).getError().toString());
                }
            }
            catch (URISyntaxException e) {
                this.logger.error(e.getMessage());
            }
        });
    }
    
    private List<User> readUsersFromFile(final String fileParam) throws FileNotFoundException {
        File file;
        if (fileParam.isEmpty()) {
            file = this.getFileFromResources("users-token.csv");
        }
        else {
            file = new File(fileParam);
        }
        final FileReader csv = new FileReader(file);
        final UserCsvReader userCsvReader = new UserCsvReader(csv);
        return (List<User>)userCsvReader.getAllRows();
    }
    
    private File getFileFromResources(final String fileName) {
        final ClassLoader classLoader = this.getClass().getClassLoader();
        final URL resource = classLoader.getResource(fileName);
        if (resource == null) {
            throw new IllegalArgumentException("file is not found!");
        }
        return new File(resource.getFile());
    }
}
