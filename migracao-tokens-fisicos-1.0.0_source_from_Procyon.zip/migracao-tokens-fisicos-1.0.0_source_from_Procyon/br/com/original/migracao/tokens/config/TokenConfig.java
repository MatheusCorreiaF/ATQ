// 
// Decompiled by Procyon v0.5.36
// 

package br.com.original.migracao.tokens.config;

import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TokenConfig
{
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
